nunca notificaron que se iba a reabrir la renetrega. hoy me entere a 3 horas de finalizado el plazo. 
Pude lograr hacer un persist comun, pero por algun motivo no me persiste una publicacion. 
hice una database comun en localhost usando sql llamada pruebajava. con crear el esquema deberia funcionar