package com.cartelera.dao.interfaces;

import com.cartelera.model.Cartelera;

public interface CarteleraDAO extends GenericDAO<Cartelera> {
}
