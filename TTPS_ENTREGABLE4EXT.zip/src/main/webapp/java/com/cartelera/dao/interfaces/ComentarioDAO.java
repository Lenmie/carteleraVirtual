package com.cartelera.dao.interfaces;

import com.cartelera.model.Comentario;

public interface ComentarioDAO extends GenericDAO<Comentario>{

}
