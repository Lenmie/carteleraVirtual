package com.cartelera.dao.interfaces;

import com.cartelera.model.UsuarioPerfil;

public interface UsuarioPerfilDAO extends GenericDAO<UsuarioPerfil>{


}
