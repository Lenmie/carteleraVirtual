package com.cartelera.dao.interfaces;

import com.cartelera.model.Publicacion;

public interface PublicacionDAO extends GenericDAO<Publicacion> {
}
