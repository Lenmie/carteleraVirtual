package com.cartelera.model;

import javax.persistence.*;

@Entity
@Table
public class Publicador extends Perfil{

}
