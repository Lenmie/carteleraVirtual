package com.cartelera.dao;

import com.cartelera.model.Administrador;

public class AdministradorDAO extends GenericDAOHibernateJPA<Administrador> {


}
