package com.cartelera.dao;
import com.cartelera.model.Usuario;

public class UsuarioHIbernateJPA extends GenericDAOHibernateJPA<Usuario> implements UsuarioDAO {

    public UsuarioHIbernateJPA(){
        super(Usuario.class);
    }
}
