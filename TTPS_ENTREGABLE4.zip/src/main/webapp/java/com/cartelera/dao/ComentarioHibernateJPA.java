package com.cartelera.dao;

import com.cartelera.model.Comentario;

public class ComentarioHIbernateJPA extends GenericDAOHibernateJPA<Comentario> implements ComentarioDAO {

    public ComentarioHIbernateJPA(){
        super(Comentario.class);
    }
}
