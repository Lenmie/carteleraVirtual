package com.cartelera.dao;

import com.cartelera.model.Usuario;

public interface UsuarioDAO extends GenericDAO<Usuario>{


}
