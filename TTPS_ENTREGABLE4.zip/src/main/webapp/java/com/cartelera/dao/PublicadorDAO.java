package com.cartelera.dao;

import com.cartelera.model.Publicador;

public class PublicadorDAO extends GenericDAOHibernateJPA<Publicador>{
}
