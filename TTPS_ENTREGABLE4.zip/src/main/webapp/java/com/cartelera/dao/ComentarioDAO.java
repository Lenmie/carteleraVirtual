package com.cartelera.dao;

import com.cartelera.model.Comentario;

public interface ComentarioDAO extends GenericDAO<Comentario>{

}
